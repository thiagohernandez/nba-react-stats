import React from "react";
import CardTeam from "./Components/CardTeam/CardTeam";

const Home = () => {
  const aux = {1:'loading'}
  const [firstTeams, setFirstTeams] = React.useState(aux);

  React.useEffect(() => {
    const fetchData = async () => {
      const res = await fetch(
        "https://www.balldontlie.io/api/v1/teams" //example and simple data
      );
      const response = await res.json();
      setFirstTeams(response.data); // parse json
      console.log(response);
    };
    fetchData();
  }, []);
  console.log(firstTeams);

  return (
    <div className="container animRight">
      <div className="pageHeader">
        <div className="pageTitle">
          <h1>Home</h1>
        </div>
      </div>
      {firstTeams != null && firstTeams.map ? firstTeams.map((item) => (
        <CardTeam key={item.id} data={item} />
      )): ''
      } 
    </div>
  );
};

export default Home;
