import React from 'react';
import { Link } from 'react-router-dom';

const CardTeam = ({data}) => {

  return (
    <Link className="cardTeam" to={`/team/${data.id}`} key={data.id}>
        <div className="cardTeamBody">
            <div className="badge">{data.conference}</div>
            <h3>{data.name}</h3>
        </div>
    </Link>
  );
}

export default CardTeam;