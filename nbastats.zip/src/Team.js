import React from "react";
import { useParams } from "react-router-dom";

const Team = () => {
    const { id } = useParams();
  const aux = {1:'loading'}
  const [firstTeams, setFirstTeams] = React.useState(aux);

  React.useEffect(() => {
    const fetchData = async () => {
      const res = await fetch(
        `https://www.balldontlie.io/api/v1/teams/${id}`
      );
      const response = await res.json();
      setFirstTeams(response.data); // parse json
      console.log(response);
    };
    fetchData();
  }, [id]);


  return (
    <div className="container animRight">
      <div className="pageHeader">
        <div className="pageTitle">
          <h1>Team {firstTeams.name} </h1>
        </div>
      </div>
      {firstTeams.id} 
      
    </div>
  );
};

export default Team;
